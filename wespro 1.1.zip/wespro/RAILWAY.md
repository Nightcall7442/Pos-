# Деплой Wespro на Railway

Railway даёт каждому сервису бесплатный публичный адрес вида
`your-service.up.railway.app` — свой домен покупать не нужно.

Проект — это 3 отдельных сервиса в одном Railway-проекте:

- **backend** — API (Express + Prisma + SQLite), публичный домен НЕ нужен
- **admin** — панель администратора (nginx + статика)
- **terminal** — POS-терминал (nginx + статика)

## 1. Создать проект и три сервиса

В Railway: **New Project → Deploy from GitHub repo** (или загрузить архив,
если репозитория ещё нет). Затем на один и тот же репозиторий добавь **3
сервиса** (`+ New → GitHub Repo`, тот же репозиторий трижды), и для каждого
в **Settings → Root Directory** укажи:

| Сервис     | Root Directory   |
|------------|-------------------|
| `backend`  | `backend`         |
| `admin`    | `frontend-admin`  |
| `terminal` | `pos-terminal`    |

Railway сам найдёт `Dockerfile` в каждой папке и будет собирать через него.

## 2. Backend — переменные окружения

В сервисе `backend` → **Variables** добавь:

```
PORT=3000
NODE_ENV=production
DATABASE_URL=file:/data/wespro.db
JWT_SECRET=<сгенерированное ниже значение>
JWT_REFRESH_SECRET=<сгенерированное ниже значение>
JWT_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d
CORS_ORIGIN=https://<домен-admin>.up.railway.app
UPLOAD_DIR=./uploads
MAX_FILE_SIZE=5242880
LOG_LEVEL=info
```

`CORS_ORIGIN` практически не используется в обычной работе — admin и
terminal обращаются к backend через свой же nginx (см. шаг 3-4), это
same-origin запрос с точки зрения браузера. Можно оставить любое значение
на шаге создания сервиса и вернуться к нему после шага 5, когда появится
реальный домен admin (пригодится только для прямых тестов API, напр. curl).

**Важно:** НЕ используй значения из локального `.env` для разработки —
это публичный сервер. Сгенерируй свои секреты (32 случайных байта в hex),
например через `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
— выполни дважды, для `JWT_SECRET` и `JWT_REFRESH_SECRET` по отдельности.

### Volume (обязательно!)

Без этого база будет удаляться при каждом деплое. В сервисе `backend` →
**Settings → Volumes → New Volume**, указать mount path:

```
/data
```

Именно `/data`, а не `/app/prisma` — та папка занята файлом схемы Prisma
внутри образа, монтирование volume поверх неё стёрло бы схему. `DATABASE_URL`
выше (`file:/data/wespro.db`) указывает на файл БД уже внутри примонтированного
тома, так что `dev.db` переживёт редеплои и перезапуски.

### Первый запуск

Схема БД создастся автоматически при старте контейнера (это уже настроено
в `backend/Dockerfile`). А вот demo-данные (категории/товары/пользователей)
нужно засеять один раз вручную — в Railway откудрой **Shell** для сервиса
`backend` (или через Railway CLI: `railway run --service backend npm run db:seed`)
и выполни:

```
npm run db:seed
```

Дальше уже создавай реальных пользователей и товары через админку — сиды
повторно не запускай (они не проверяют дубликаты).

### Публичный домен backend НЕ нужен

Backend вызывается только изнутри Railway (из admin/terminal через приватную
сеть), наружу его открывать необязательно — так безопаснее.

## 3. Найти внутренний адрес backend

В сервисе `backend` → **Settings → Networking** — там будет **Private
Networking** домен вида:

```
backend.railway.internal
```

(имя обычно совпадает с именем сервиса). Скопируй этот адрес — он
понадобится для admin и terminal.

## 4. Admin и Terminal — переменные окружения

В сервисах `admin` и `terminal` → **Variables** добавь ОДНУ переменную
(значение — из шага 3 плюс порт backend):

```
BACKEND_URL=backend.railway.internal:3000
```

(Замени `backend` на реальное имя твоего backend-сервиса, если оно другое.)

## 5. Публичные домены для admin и terminal

В сервисах `admin` и `terminal` → **Settings → Networking → Generate
Domain**. Railway выдаст бесплатные адреса вида:

```
wespro-admin-production.up.railway.app
wespro-terminal-production.up.railway.app
```

Это и есть публичные ссылки — их можно открывать с любого устройства,
не только из локальной сети.

## 6. Проверка

1. Открой домен `terminal` → должен показаться экран входа POS-терминала.
2. Открой домен `admin` → должен показаться экран входа админки.
3. Залогинься (после `db:seed`): `admin@wespro.com` / `admin123`.
4. **Сразу смени пароли** реальных пользователей — это публичный адрес.

## Частые проблемы

- **502 / Bad Gateway на admin или terminal** — неверный `BACKEND_URL` или
  backend ещё не поднялся. Проверь Settings → Networking у backend и
  логи backend-сервиса.
- **"no such table" в логах backend** — volume не подключён или подключён
  не туда; проверь mount path `/app/prisma`.
- **CORS-ошибки в консоли браузера** — не должно происходить (admin/terminal
  обращаются к backend через свой же nginx, а не напрямую), но если
  видишь их — проверь, что `BACKEND_URL` указывает именно на internal-домен,
  а не на публичный URL backend.
