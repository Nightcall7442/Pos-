import { Router } from "express";
import { auditController } from "../modules/audit/audit.controller.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = Router();

router.use(authenticate);
router.use(authorize("admin", "manager"));

router.get("/", (req, res) => auditController.findAll(req, res));

export default router;
