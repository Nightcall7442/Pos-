import { Router } from "express";
import { cashShiftController } from "../modules/cash-shifts/cash-shift.controller.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = Router();

router.use(authenticate);

router.get("/", (req, res) => cashShiftController.findAll(req, res));
router.get("/current", (req, res) => cashShiftController.getCurrentShift(req, res));
router.get("/:id", (req, res) => cashShiftController.findById(req, res));
router.post("/open", (req, res) => cashShiftController.openShift(req, res));
router.post("/:id/close", (req, res) => cashShiftController.closeShift(req, res));

export default router;
