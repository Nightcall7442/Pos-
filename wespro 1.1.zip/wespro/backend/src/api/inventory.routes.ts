import { Router } from "express";
import { inventoryController } from "../modules/inventory/inventory.controller.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { adjustStockSchema } from "../modules/common.schema.js";

const router = Router();

router.use(authenticate);

router.get("/stock", (req, res) => inventoryController.getStock(req, res));
router.get("/movements", (req, res) => inventoryController.getMovements(req, res));
router.get("/alerts", (req, res) => inventoryController.getLowStockAlerts(req, res));
router.post("/:id/adjust", authorize("admin", "manager"), validate(adjustStockSchema), (req, res) => inventoryController.adjustStock(req, res));

export default router;
