import { Router } from "express";
import { orderController } from "../modules/orders/order.controller.js";
import { authenticate } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { createOrderSchema, updateOrderStatusSchema } from "../modules/orders/order.schema.js";

const router = Router();

router.use(authenticate);

router.get("/active", (req, res) => orderController.getActive(req, res));
router.get("/", (req, res) => orderController.findAll(req, res));
router.get("/:id", (req, res) => orderController.findById(req, res));
router.post("/", validate(createOrderSchema), (req, res) => orderController.create(req, res));
router.patch("/:id/status", validate(updateOrderStatusSchema), (req, res) => orderController.updateStatus(req, res));
router.post("/:id/cancel", (req, res) => orderController.cancel(req, res));

export default router;
