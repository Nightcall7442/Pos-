import { Router } from "express";
import { paymentController } from "../modules/payments/payment.controller.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { createPaymentSchema, refundPaymentSchema } from "../modules/payments/payment.schema.js";

const router = Router();

router.use(authenticate);

router.get("/", (req, res) => paymentController.findAll(req, res));
router.get("/summary", authorize("admin", "manager"), (req, res) => paymentController.getSummary(req, res));
router.post("/", authorize("admin", "manager", "cashier"), validate(createPaymentSchema), (req, res) => paymentController.create(req, res));
router.post("/:id/refund", authorize("admin", "manager"), validate(refundPaymentSchema), (req, res) => paymentController.refund(req, res));

export default router;
