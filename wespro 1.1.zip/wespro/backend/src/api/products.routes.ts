import { Router } from "express";
import { productController } from "../modules/products/product.controller.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { createProductSchema, updateProductSchema } from "../modules/products/product.schema.js";
import { adjustStockSchema } from "../modules/common.schema.js";

const router = Router();

router.use(authenticate);

router.get("/", (req, res) => productController.findAll(req, res));
router.get("/ingredients", (req, res) => productController.getIngredients(req, res));
router.get("/:id", (req, res) => productController.findById(req, res));
router.get("/:id/tech-card-cost", (req, res) => productController.calculateTechCardCost(req, res));
router.post("/", authorize("admin", "manager"), validate(createProductSchema), (req, res) => productController.create(req, res));
router.put("/:id", authorize("admin", "manager"), validate(updateProductSchema), (req, res) => productController.update(req, res));
router.delete("/:id", authorize("admin", "manager"), (req, res) => productController.delete(req, res));
router.post("/:id/stock", authorize("admin", "manager"), validate(adjustStockSchema), (req, res) => productController.adjustStock(req, res));

export default router;
