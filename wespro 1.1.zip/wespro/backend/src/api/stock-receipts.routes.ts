import { Router } from "express";
import { stockReceiptController } from "../modules/stock-receipts/stock-receipt.controller.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { createStockReceiptSchema } from "../modules/stock-receipts/stock-receipt.schema.js";

const router = Router();

router.use(authenticate);

router.get("/", (req, res) => stockReceiptController.findAll(req, res));
router.get("/:id", (req, res) => stockReceiptController.findById(req, res));
router.post("/", authorize("admin", "manager", "cashier"), validate(createStockReceiptSchema), (req, res) => stockReceiptController.create(req, res));
router.delete("/:id", authorize("admin", "manager"), (req, res) => stockReceiptController.delete(req, res));

export default router;
