import { Router } from "express";
import { tableController } from "../modules/tables/table.controller.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { createTableSchema, updateTableSchema, updateTableStatusSchema } from "../modules/tables/table.schema.js";

const router = Router();

router.use(authenticate);

router.get("/", (req, res) => tableController.findAll(req, res));
router.get("/stats", (req, res) => tableController.getStats(req, res));
router.get("/:id", (req, res) => tableController.findById(req, res));
router.post("/", authorize("admin", "manager"), validate(createTableSchema), (req, res) => tableController.create(req, res));
router.put("/:id", authorize("admin", "manager"), validate(updateTableSchema), (req, res) => tableController.update(req, res));
router.patch("/:id/status", validate(updateTableStatusSchema), (req, res) => tableController.updateStatus(req, res));
router.delete("/:id", authorize("admin", "manager"), (req, res) => tableController.delete(req, res));

export default router;
