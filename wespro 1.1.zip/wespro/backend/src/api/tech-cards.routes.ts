import { Router } from "express";
import { techCardController } from "../modules/tech-cards/tech-card.controller.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { createTechCardSchema, updateTechCardSchema } from "../modules/tech-cards/tech-card.schema.js";

const router = Router();

router.use(authenticate);

router.get("/", (req, res) => techCardController.findAll(req, res));
router.get("/:id", (req, res) => techCardController.findById(req, res));
router.post("/", authorize("admin", "manager"), validate(createTechCardSchema), (req, res) => techCardController.create(req, res));
router.put("/:id", authorize("admin", "manager"), validate(updateTechCardSchema), (req, res) => techCardController.update(req, res));
router.delete("/:id", authorize("admin", "manager"), (req, res) => techCardController.delete(req, res));
router.post("/:id/copy", authorize("admin", "manager"), (req, res) => techCardController.copy(req, res));
router.post("/:id/recalculate", authorize("admin", "manager"), (req, res) => techCardController.recalculateCost(req, res));

export default router;
