import { Router } from "express";
import { userController } from "../modules/users/user.controller.js";
import { authenticate, authorize } from "../middleware/auth.js";
import { validate } from "../middleware/validate.js";
import { createUserSchema, updateUserSchema } from "../modules/users/user.schema.js";

const router = Router();

router.use(authenticate);

router.get("/", (req, res) => userController.findAll(req, res));
router.get("/:id", (req, res) => userController.findById(req, res));
router.post("/", authorize("admin", "manager"), validate(createUserSchema), (req, res) => userController.create(req, res));
router.put("/:id", authorize("admin", "manager"), validate(updateUserSchema), (req, res) => userController.update(req, res));
router.delete("/:id", authorize("admin"), (req, res) => userController.delete(req, res));
router.post("/:id/toggle", authorize("admin", "manager"), (req, res) => userController.toggleActive(req, res));

export default router;
