import { Request, Response, NextFunction } from "express";
import { auditService } from "../modules/audit/audit.service.js";

interface AuditRequest extends Request {
  user?: {
    id: string;
    tenantId: string;
    email: string;
    role: string;
    firstName: string;
    lastName: string;
  };
  auditData?: {
    action: string;
    entityType?: string;
    entityId?: string;
    oldValue?: string;
    newValue?: string;
  };
}

export function auditLog(action: string, entityType?: string) {
  return (req: AuditRequest, res: Response, next: NextFunction): void => {
    req.auditData = { action, entityType };
    const originalJson = res.json.bind(res);

    res.json = function (body: any) {
      if (req.user && res.statusCode >= 200 && res.statusCode < 300) {
        const data = req.auditData!;
        auditService.log({
          tenantId: req.user.tenantId,
          userId: req.user.id,
          action: data.action,
          entityType: data.entityType,
          entityId: req.params.id || body?.data?.id,
          newValue: JSON.stringify(body?.data),
          ipAddress: req.ip,
          userAgent: req.get("user-agent"),
        }).catch(() => {});
      }
      return originalJson(body);
    };

    next();
  };
}
