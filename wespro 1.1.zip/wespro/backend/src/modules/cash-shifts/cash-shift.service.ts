import prisma from "../../config/database.js";

export class CashShiftService {
  async openShift(tenantId: string, userId: string, openingCash: number, notes?: string) {
    const activeShift = await prisma.cashShift.findFirst({
      where: { tenantId, userId, status: "open" },
    });
    if (activeShift) throw new Error("У вас уже есть открытая смена");

    const shift = await prisma.cashShift.create({
      data: {
        tenantId,
        userId,
        openingCash,
        notes,
        status: "open",
      },
      include: {
        user: { select: { id: true, firstName: true, lastName: true } },
      },
    });

    return shift;
  }

  async closeShift(tenantId: string, shiftId: string, userId: string, closingCash: number, notes?: string) {
    const shift = await prisma.cashShift.findFirst({
      where: { id: shiftId, tenantId, status: "open" },
    });
    if (!shift) throw new Error("Смена не найдена или уже закрыта");
    if (shift.userId !== userId) throw new Error("Нет прав закрыть чужую смену");

    const payments = await prisma.payment.findMany({
      where: {
        tenantId,
        status: "completed",
        createdAt: { gte: shift.openedAt },
      },
    });

    let totalCashSales = 0;
    let totalCardSales = 0;
    let totalQrSales = 0;
    let totalTips = 0;
    let totalRefunds = 0;

    for (const payment of payments) {
      if (payment.method === "cash") totalCashSales += payment.amount;
      else if (payment.method === "card") totalCardSales += payment.amount;
      else if (payment.method === "qr") totalQrSales += payment.amount;
      totalTips += payment.tipAmount;
    }

    const refunds = await prisma.payment.findMany({
      where: {
        tenantId,
        status: "refunded",
        createdAt: { gte: shift.openedAt },
      },
    });
    totalRefunds = refunds.reduce((sum, p) => sum + p.amount, 0);

    const totalSales = totalCashSales + totalCardSales + totalQrSales;
    const expectedCash = shift.openingCash + totalCashSales - totalRefunds;
    const difference = closingCash - expectedCash;

    const updatedShift = await prisma.cashShift.update({
      where: { id: shiftId },
      data: {
        status: "closed",
        closingCash,
        totalSales,
        totalCashSales,
        totalCardSales,
        totalQrSales,
        totalTips,
        totalRefunds,
        expectedCash,
        difference,
        notes: notes ? `${shift.notes || ""}\n${notes}`.trim() : shift.notes,
        closedAt: new Date(),
      },
      include: {
        user: { select: { id: true, firstName: true, lastName: true } },
      },
    });

    return updatedShift;
  }

  async getCurrentShift(tenantId: string, userId: string) {
    const shift = await prisma.cashShift.findFirst({
      where: { tenantId, userId, status: "open" },
      include: {
        user: { select: { id: true, firstName: true, lastName: true } },
        orders: {
          select: { id: true, orderNumber: true, total: true, status: true, createdAt: true },
          orderBy: { createdAt: "desc" },
        },
      },
    });
    return shift;
  }

  async findAll(tenantId: string, query: any) {
    const { page = 1, limit = 20, status, userId } = query;
    const skip = (page - 1) * limit;

    const where: any = { tenantId };
    if (status) where.status = status;
    if (userId) where.userId = userId;

    const [shifts, total] = await Promise.all([
      prisma.cashShift.findMany({
        where,
        include: {
          user: { select: { id: true, firstName: true, lastName: true } },
          _count: { select: { orders: true } },
        },
        orderBy: { openedAt: "desc" },
        skip,
        take: limit,
      }),
      prisma.cashShift.count({ where }),
    ]);

    return { shifts, total, page, limit };
  }

  async findById(tenantId: string, id: string) {
    const shift = await prisma.cashShift.findFirst({
      where: { id, tenantId },
      include: {
        user: { select: { id: true, firstName: true, lastName: true } },
        orders: {
          include: {
            items: { select: { quantity: true, totalPrice: true } },
            payments: { select: { method: true, amount: true, status: true } },
          },
          orderBy: { createdAt: "desc" },
        },
      },
    });
    if (!shift) throw new Error("Смена не найдена");
    return shift;
  }
}

export const cashShiftService = new CashShiftService();
