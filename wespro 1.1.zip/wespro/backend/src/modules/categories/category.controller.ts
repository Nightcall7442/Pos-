import { Request, Response } from "express";
import { categoryService } from "./category.service.js";
import { sendSuccess, sendCreated, sendError } from "../../utils/response.js";

export class CategoryController {
  async findAll(req: Request, res: Response) {
    try {
      const categories = await categoryService.findAll(req.user!.tenantId);
      sendSuccess(res, categories);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async findTree(req: Request, res: Response) {
    try {
      const categories = await categoryService.findTree(req.user!.tenantId);
      sendSuccess(res, categories);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async findById(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const category = await categoryService.findById(req.user!.tenantId, id);
      sendSuccess(res, category);
    } catch (error: any) {
      sendError(res, error.message, 404);
    }
  }

  async create(req: Request, res: Response) {
    try {
      const category = await categoryService.create(req.user!.tenantId, req.body);
      sendCreated(res, category);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async update(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const category = await categoryService.update(req.user!.tenantId, id, req.body);
      sendSuccess(res, category);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async delete(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      await categoryService.delete(req.user!.tenantId, id);
      sendSuccess(res, null, "Category deleted");
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async reorder(req: Request, res: Response) {
    try {
      await categoryService.reorder(req.user!.tenantId, req.body.ids);
      sendSuccess(res, null, "Categories reordered");
    } catch (error: any) {
      sendError(res, error.message);
    }
  }
}

export const categoryController = new CategoryController();
