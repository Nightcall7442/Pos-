import prisma from "../../config/database.js";
import type { CreateCategoryInput, UpdateCategoryInput } from "./category.schema.js";

export class CategoryService {
  async findAll(tenantId: string) {
    return prisma.category.findMany({
      where: { tenantId },
      include: {
        children: { orderBy: { sortOrder: "asc" } },
        _count: { select: { products: { where: { isActive: true } } } },
      },
      orderBy: { sortOrder: "asc" },
    });
  }

  async findTree(tenantId: string) {
    return prisma.category.findMany({
      where: { tenantId, parentId: null },
      include: {
        children: {
          include: { _count: { select: { products: { where: { isActive: true } } } } },
          orderBy: { sortOrder: "asc" },
        },
        _count: { select: { products: { where: { isActive: true } } } },
      },
      orderBy: { sortOrder: "asc" },
    });
  }

  async findById(tenantId: string, id: string) {
    const category = await prisma.category.findFirst({
      where: { id, tenantId },
      include: {
        parent: { select: { id: true, name: true } },
        children: { orderBy: { sortOrder: "asc" } },
        _count: { select: { products: { where: { isActive: true } } } },
      },
    });
    if (!category) throw new Error("Category not found");
    return category;
  }

  async create(tenantId: string, data: CreateCategoryInput) {
    return prisma.category.create({
      data: { ...data, tenantId },
    });
  }

  async update(tenantId: string, id: string, data: UpdateCategoryInput) {
    const category = await prisma.category.findFirst({ where: { id, tenantId } });
    if (!category) throw new Error("Category not found");

    return prisma.category.update({
      where: { id },
      data,
    });
  }

  async delete(tenantId: string, id: string) {
    const category = await prisma.category.findFirst({
      where: { id, tenantId },
      include: { products: { where: { isActive: true }, take: 1 } },
    });
    if (!category) throw new Error("Category not found");
    if (category.products.length > 0) {
      throw new Error("Cannot delete category with active products");
    }

    await prisma.category.delete({ where: { id } });
    return { message: "Category deleted" };
  }

  async reorder(tenantId: string, ids: string[]) {
    const updates = ids.map((id, index) =>
      prisma.category.update({
        where: { id },
        data: { sortOrder: index },
      })
    );
    await prisma.$transaction(updates);
    return { message: "Categories reordered" };
  }
}

export const categoryService = new CategoryService();
