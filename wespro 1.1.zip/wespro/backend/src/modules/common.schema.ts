import { z } from "zod";

export const adjustStockSchema = z.object({
  quantity: z.number().int(),
  reason: z.string().min(1),
});

export const reorderCategoriesSchema = z.object({
  ids: z.array(z.string().uuid()).min(1),
});

export const reportQuerySchema = z.object({
  dateFrom: z.string().min(1, "dateFrom is required"),
  dateTo: z.string().min(1, "dateTo is required"),
});

export type AdjustStockInput = z.infer<typeof adjustStockSchema>;
export type ReorderCategoriesInput = z.infer<typeof reorderCategoriesSchema>;
export type ReportQueryInput = z.infer<typeof reportQuerySchema>;
