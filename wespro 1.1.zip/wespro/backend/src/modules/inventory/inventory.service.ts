import prisma from "../../config/database.js";

export class InventoryService {
  async getStock(tenantId: string, query: any) {
    const { lowStock, categoryId, search, page = 1, limit = 50 } = query;
    const skip = (page - 1) * limit;

    const where: any = { tenantId, isActive: true };
    if (categoryId) where.categoryId = categoryId;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { sku: { contains: search } },
      ];
    }

    const [allProducts, total] = await Promise.all([
      prisma.product.findMany({
        where,
        select: {
          id: true,
          name: true,
          sku: true,
          currentStock: true,
          minStock: true,
          costPrice: true,
          price: true,
          imageUrl: true,
          trackInventory: true,
          purchaseUnit: true,
          saleUnit: true,
          conversionFactor: true,
          category: { select: { id: true, name: true } },
        },
        orderBy: { name: "asc" },
      }),
      prisma.product.count({ where }),
    ]);

    let products = allProducts;
    if (lowStock) {
      products = allProducts.filter((p) => p.trackInventory && p.currentStock <= p.minStock);
    }

    const paginated = products.slice(skip, skip + limit);
    return { products: paginated, total: products.length, page, limit };
  }

  async getMovements(tenantId: string, query: any) {
    const { productId, type, page = 1, limit = 20 } = query;
    const skip = (page - 1) * limit;

    const where: any = { tenantId };
    if (productId) where.productId = productId;
    if (type) where.type = type;

    const [movements, total] = await Promise.all([
      prisma.inventoryMovement.findMany({
        where,
        include: {
          product: { select: { id: true, name: true, sku: true } },
          user: { select: { id: true, firstName: true, lastName: true } },
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
      }),
      prisma.inventoryMovement.count({ where }),
    ]);

    return { movements, total, page, limit };
  }

  async adjustStock(tenantId: string, productId: string, quantity: number, reason: string, userId: string) {
    const product = await prisma.product.findFirst({ where: { id: productId, tenantId } });
    if (!product) throw new Error("Product not found");

    let adjustedQuantity = quantity;
    if (product.conversionFactor && product.purchaseUnit && product.saleUnit) {
      if (quantity > 0) {
        adjustedQuantity = quantity * product.conversionFactor;
      }
    }

    const newStock = product.currentStock + adjustedQuantity;
    if (newStock < 0) throw new Error("Stock cannot be negative");

    const [updated] = await prisma.$transaction([
      prisma.product.update({
        where: { id: productId },
        data: { currentStock: newStock },
      }),
      prisma.inventoryMovement.create({
        data: {
          tenantId,
          productId,
          type: quantity > 0 ? "in" : "out",
          quantity: Math.abs(adjustedQuantity),
          reason,
          userId,
        },
      }),
    ]);

    return updated;
  }

  async getLowStockAlerts(tenantId: string) {
    const products = await prisma.product.findMany({
      where: {
        tenantId,
        trackInventory: true,
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        sku: true,
        currentStock: true,
        minStock: true,
        category: { select: { name: true } },
      },
      orderBy: { currentStock: "asc" },
    });

    return products.filter((p) => p.currentStock <= p.minStock);
  }
}

export const inventoryService = new InventoryService();
