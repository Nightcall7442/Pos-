import { Request, Response } from "express";
import { notificationsService } from "./notifications.service.js";
import { sendSuccess, sendError } from "../../utils/response.js";

export class NotificationsController {
  async get(req: Request, res: Response) {
    try {
      const data = await notificationsService.getNotifications(req.user!.tenantId);
      sendSuccess(res, data);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }
}

export const notificationsController = new NotificationsController();
