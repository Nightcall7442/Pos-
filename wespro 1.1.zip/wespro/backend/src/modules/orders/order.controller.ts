import { Request, Response } from "express";
import { orderService } from "./order.service.js";
import { sendSuccess, sendCreated, sendError, sendPaginated } from "../../utils/response.js";
import type { OrderQueryInput } from "./order.schema.js";

export class OrderController {
  async findAll(req: Request, res: Response) {
    try {
      const query: OrderQueryInput = {
        status: req.query.status as string,
        type: req.query.type as string,
        branchId: req.query.branchId as string,
        tableId: req.query.tableId as string,
        dateFrom: req.query.dateFrom as string,
        dateTo: req.query.dateTo as string,
        search: req.query.search as string,
        sort: (req.query.sort as any) || "createdAt",
        order: (req.query.order as any) || "desc",
        page: Number(req.query.page) || 1,
        limit: Number(req.query.limit) || 20,
      };
      const { orders, total, page, limit } = await orderService.findAll(req.user!.tenantId, query);
      sendPaginated(res, orders, total, page, limit);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async findById(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const order = await orderService.findById(req.user!.tenantId, id);
      sendSuccess(res, order);
    } catch (error: any) {
      sendError(res, error.message, 404);
    }
  }

  async create(req: Request, res: Response) {
    try {
      const order = await orderService.create(req.user!.tenantId, req.user!.id, req.body);
      sendCreated(res, order);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async updateStatus(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const order = await orderService.updateStatus(req.user!.tenantId, id, req.body);
      sendSuccess(res, order);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async cancel(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const order = await orderService.cancel(req.user!.tenantId, id, req.user!.id);
      sendSuccess(res, order);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async getActive(req: Request, res: Response) {
    try {
      const branchId = req.query.branchId as string | undefined;
      const orders = await orderService.getActiveOrders(req.user!.tenantId, branchId);
      sendSuccess(res, orders);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }
}

export const orderController = new OrderController();
