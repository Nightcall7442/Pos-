import { z } from "zod";

const orderItemSchema = z.object({
  productId: z.string().uuid(),
  quantity: z.number().int().min(1),
  unitPrice: z.number().min(0),
  notes: z.string().optional(),
  modifierIds: z.array(z.string().uuid()).optional(),
});

export const createOrderSchema = z.object({
  branchId: z.string().uuid().optional(),
  tableId: z.string().uuid().optional(),
  cashShiftId: z.string().uuid().optional(),
  type: z.enum(["dine_in", "takeaway", "delivery", "online"]),
  items: z.array(orderItemSchema).min(1, "At least one item required"),
  customerName: z.string().optional(),
  customerPhone: z.string().optional(),
  notes: z.string().optional(),
  discountAmount: z.number().min(0).optional(),
});

export const updateOrderStatusSchema = z.object({
  status: z.enum(["confirmed", "preparing", "ready", "served", "completed", "cancelled"]),
});

export const orderQuerySchema = z.object({
  status: z.string().optional(),
  type: z.string().optional(),
  branchId: z.string().uuid().optional(),
  tableId: z.string().uuid().optional(),
  dateFrom: z.string().optional(),
  dateTo: z.string().optional(),
  search: z.string().optional(),
  sort: z.enum(["createdAt", "total", "orderNumber"]).optional(),
  order: z.enum(["asc", "desc"]).optional(),
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
});

export type CreateOrderInput = z.infer<typeof createOrderSchema>;
export type UpdateOrderStatusInput = z.infer<typeof updateOrderStatusSchema>;
export type OrderQueryInput = z.infer<typeof orderQuerySchema>;
