import prisma from "../../config/database.js";
import type { CreateOrderInput, UpdateOrderStatusInput, OrderQueryInput } from "./order.schema.js";
import { Server as SocketIOServer } from "socket.io";

let io: SocketIOServer;

export function setSocketIO(socketIO: SocketIOServer) {
  io = socketIO;
}

export class OrderService {
  async findAll(tenantId: string, query: OrderQueryInput) {
    const { status, type, branchId, tableId, dateFrom, dateTo, search, sort = "createdAt", order = "desc", page = 1, limit = 20 } = query;
    const skip = (page - 1) * limit;

    const where: any = { tenantId };
    if (status) where.status = status;
    if (type) where.type = type;
    if (branchId) where.branchId = branchId;
    if (tableId) where.tableId = tableId;
    if (dateFrom || dateTo) {
      where.createdAt = {};
      if (dateFrom) where.createdAt.gte = new Date(dateFrom);
      if (dateTo) where.createdAt.lte = new Date(dateTo);
    }
    if (search) {
      where.OR = [
        { customerName: { contains: search } },
        { customerPhone: { contains: search } },
      ];
    }

    const orderBy: any = { [sort]: order };

    const [orders, total] = await Promise.all([
      prisma.order.findMany({
        where,
        include: {
          items: {
            include: {
              product: { select: { id: true, name: true, imageUrl: true } },
              modifiers: { include: { modifierItem: true } },
            },
          },
          user: { select: { id: true, firstName: true, lastName: true } },
          table: { select: { id: true, number: true } },
          payments: { select: { id: true, method: true, amount: true, status: true } },
        },
        orderBy,
        skip,
        take: limit,
      }),
      prisma.order.count({ where }),
    ]);

    return { orders, total, page, limit };
  }

  async findById(tenantId: string, id: string) {
    const order = await prisma.order.findFirst({
      where: { id, tenantId },
      include: {
        items: {
          include: {
            product: true,
            modifiers: { include: { modifierItem: true } },
          },
        },
        user: { select: { id: true, firstName: true, lastName: true } },
        table: true,
        branch: { select: { id: true, name: true } },
        payments: true,
        receipts: true,
      },
    });
    if (!order) throw new Error("Order not found");
    return order;
  }

  async create(tenantId: string, userId: string, data: CreateOrderInput) {
    let subtotal = 0;
    const orderItems: any[] = [];

    for (const item of data.items) {
      const product = await prisma.product.findFirst({
        where: { id: item.productId, tenantId, isActive: true },
      });
      if (!product) throw new Error(`Product ${item.productId} not found`);

      // Weighted products (sold by gram) send a pre-computed price (rate × grams)
      // that the server can't reconstruct on its own. Everything else is priced
      // from the current product record, never trusted from the client — this
      // is what stops a stale cart or a tampered request from selling at a
      // wrong/old price.
      const isWeighted = product.saleUnit === "г";
      const unitPrice = isWeighted ? item.unitPrice : product.price;

      let itemTotal = unitPrice * item.quantity;

      const modifierItems: any[] = [];
      if (item.modifierIds?.length) {
        const modifiers = await prisma.modifierItem.findMany({
          where: { id: { in: item.modifierIds } },
        });
        for (const mod of modifiers) {
          itemTotal += mod.price * item.quantity;
          modifierItems.push({ modifierItemId: mod.id, price: mod.price });
        }
      }

      subtotal += itemTotal;

      orderItems.push({
        productId: item.productId,
        quantity: item.quantity,
        unitPrice,
        totalPrice: itemTotal,
        notes: item.notes,
        modifiers: { create: modifierItems },
      });
    }

    const discountAmount = data.discountAmount || 0;
    const total = subtotal - discountAmount;

    const lastOrder = await prisma.order.findFirst({
      where: { tenantId },
      orderBy: { orderNumber: "desc" },
      select: { orderNumber: true },
    });
    const orderNumber = (lastOrder?.orderNumber || 0) + 1;

    const order = await prisma.order.create({
      data: {
        tenantId,
        userId,
        branchId: data.branchId,
        tableId: data.tableId,
        cashShiftId: data.cashShiftId,
        orderNumber,
        type: data.type,
        subtotal,
        taxAmount: 0,
        discountAmount,
        total,
        customerName: data.customerName,
        customerPhone: data.customerPhone,
        notes: data.notes,
        items: { create: orderItems },
      },
      include: {
        items: {
          include: {
            product: { select: { id: true, name: true, imageUrl: true } },
            modifiers: { include: { modifierItem: true } },
          },
        },
        user: { select: { id: true, firstName: true, lastName: true } },
        table: { select: { id: true, number: true } },
      },
    });

    if (data.tableId) {
      await prisma.table.update({
        where: { id: data.tableId },
        data: { status: "occupied" },
      });
    }

    if (io) {
      io.to(`tenant:${tenantId}`).emit("order:created", order);
      io.to(`tenant:${tenantId}:kitchen`).emit("order:new", order);
    }

    return order;
  }

  async updateStatus(tenantId: string, id: string, data: UpdateOrderStatusInput) {
    const order = await prisma.order.findFirst({ where: { id, tenantId } });
    if (!order) throw new Error("Order not found");

    const updateData: any = { status: data.status };
    if (data.status === "completed") updateData.completedAt = new Date();

    const updated = await prisma.order.update({
      where: { id },
      data: updateData,
      include: {
        items: { include: { product: true } },
        user: { select: { id: true, firstName: true, lastName: true } },
        table: true,
      },
    });

    if (data.status === "completed" && order.tableId) {
      await prisma.table.update({
        where: { id: order.tableId },
        data: { status: "available" },
      });
    }

    if (io) {
      io.to(`tenant:${tenantId}`).emit("order:updated", updated);
    }

    return updated;
  }

  async cancel(tenantId: string, id: string, userId: string) {
    const order = await prisma.order.findFirst({ where: { id, tenantId } });
    if (!order) throw new Error("Order not found");
    if (["completed", "cancelled"].includes(order.status)) {
      throw new Error("Cannot cancel this order");
    }

    const updated = await prisma.order.update({
      where: { id },
      data: { status: "cancelled" },
    });

    if (order.tableId) {
      await prisma.table.update({
        where: { id: order.tableId },
        data: { status: "available" },
      });
    }

    if (io) {
      io.to(`tenant:${tenantId}`).emit("order:cancelled", updated);
    }

    return updated;
  }

  async getActiveOrders(tenantId: string, branchId?: string) {
    const where: any = {
      tenantId,
      status: { in: ["pending", "confirmed", "preparing", "ready", "served"] },
    };
    if (branchId) where.branchId = branchId;

    return prisma.order.findMany({
      where,
      include: {
        items: {
          include: {
            product: { select: { id: true, name: true } },
            modifiers: { include: { modifierItem: true } },
          },
        },
        user: { select: { id: true, firstName: true } },
        table: { select: { id: true, number: true } },
      },
      orderBy: { createdAt: "asc" },
    });
  }
}

export const orderService = new OrderService();
