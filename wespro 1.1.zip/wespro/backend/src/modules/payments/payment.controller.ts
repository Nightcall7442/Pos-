import { Request, Response } from "express";
import { paymentService } from "./payment.service.js";
import { sendSuccess, sendCreated, sendError, sendPaginated } from "../../utils/response.js";

export class PaymentController {
  async create(req: Request, res: Response) {
    try {
      const payment = await paymentService.create(req.user!.tenantId, req.body);
      sendCreated(res, payment);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async findAll(req: Request, res: Response) {
    try {
      const query = {
        page: Number(req.query.page) || 1,
        limit: Number(req.query.limit) || 20,
        method: req.query.method as string,
        status: req.query.status as string,
        orderId: req.query.orderId as string,
      };
      const { payments, total, page, limit } = await paymentService.findAll(req.user!.tenantId, query);
      sendPaginated(res, payments, total, page, limit);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async refund(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const payment = await paymentService.refund(req.user!.tenantId, id, req.body.reason);
      sendSuccess(res, payment, "Payment refunded");
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async getSummary(req: Request, res: Response) {
    try {
      const summary = await paymentService.getSummary(
        req.user!.tenantId,
        req.query.dateFrom as string,
        req.query.dateTo as string
      );
      sendSuccess(res, summary);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }
}

export const paymentController = new PaymentController();
