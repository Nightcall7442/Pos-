import { z } from "zod";

export const createPaymentSchema = z.object({
  orderId: z.string().uuid(),
  method: z.enum(["cash", "card", "online", "split", "gift_card"]),
  amount: z.number().min(0.01),
  tipAmount: z.number().min(0).optional(),
  transactionId: z.string().optional(),
  cardLastFour: z.string().length(4).optional(),
});

export const refundPaymentSchema = z.object({
  reason: z.string().min(1),
});

export type CreatePaymentInput = z.infer<typeof createPaymentSchema>;
export type RefundPaymentInput = z.infer<typeof refundPaymentSchema>;
