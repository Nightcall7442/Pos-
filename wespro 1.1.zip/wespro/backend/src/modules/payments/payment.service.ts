import prisma from "../../config/database.js";
import type { CreatePaymentInput } from "./payment.schema.js";

export class PaymentService {
  async create(tenantId: string, data: CreatePaymentInput) {
    const order = await prisma.order.findFirst({
      where: { id: data.orderId, tenantId },
      include: { payments: true },
    });
    if (!order) throw new Error("Order not found");
    if (order.status === "cancelled") throw new Error("Cannot pay for cancelled order");

    const totalPaid = order.payments
      .filter((p) => p.status === "completed")
      .reduce((sum, p) => sum + p.amount, 0);
    const remaining = order.total - totalPaid;

    if (data.amount > remaining + 0.01) {
      throw new Error(`Payment exceeds remaining balance of ${remaining.toFixed(2)}`);
    }

    const payment = await prisma.payment.create({
      data: {
        tenantId,
        orderId: data.orderId,
        method: data.method,
        amount: data.amount,
        tipAmount: data.tipAmount || 0,
        transactionId: data.transactionId,
        cardLastFour: data.cardLastFour,
        status: "completed",
        processedAt: new Date(),
      },
    });

    const newTotalPaid = totalPaid + data.amount;
    if (newTotalPaid >= order.total - 0.01) {
      await prisma.order.update({
        where: { id: data.orderId },
        data: { status: "completed", completedAt: new Date() },
      });

      // Списание ингредиентов по тех карте
      await this.deductIngredients(tenantId, data.orderId);

      if (order.tableId) {
        await prisma.table.update({
          where: { id: order.tableId },
          data: { status: "available" },
        });
      }
    }

    return payment;
  }

  private async deductIngredients(tenantId: string, orderId: string) {
    const orderItems = await prisma.orderItem.findMany({
      where: { orderId },
      include: { product: true },
    });

    for (const item of orderItems) {
      const techCard = JSON.parse(item.product.techCard || "[]") as { ingredientId: string; quantity: number; unit: string }[];
      if (techCard.length === 0) continue;

      for (const tc of techCard) {
        const ingredient = await prisma.product.findFirst({
          where: { id: tc.ingredientId, tenantId },
        });
        if (!ingredient) continue;

        const deductionQty = tc.quantity * item.quantity;
        const newStock = ingredient.currentStock - deductionQty;

        await prisma.$transaction([
          prisma.product.update({
            where: { id: tc.ingredientId },
            data: { currentStock: Math.max(0, newStock) },
          }),
          prisma.inventoryMovement.create({
            data: {
              tenantId,
              productId: tc.ingredientId,
              type: "out",
              quantity: deductionQty,
              reason: `Списание по тех карте: заказ #${orderId}`,
              referenceId: orderId,
            },
          }),
        ]);
      }
    }
  }

  async findAll(tenantId: string, query: any) {
    const { page = 1, limit = 20, method, status, orderId } = query;
    const skip = (page - 1) * limit;

    const where: any = { tenantId };
    if (method) where.method = method;
    if (status) where.status = status;
    if (orderId) where.orderId = orderId;

    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where,
        include: {
          order: { select: { id: true, orderNumber: true, total: true } },
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
      }),
      prisma.payment.count({ where }),
    ]);

    return { payments, total, page, limit };
  }

  async refund(tenantId: string, paymentId: string, reason: string) {
    const payment = await prisma.payment.findFirst({
      where: { id: paymentId, tenantId, status: "completed" },
      include: { order: { include: { payments: true } } },
    });
    if (!payment) throw new Error("Payment not found");

    const updated = await prisma.payment.update({
      where: { id: paymentId },
      data: { status: "refunded" },
    });

    const order = payment.order;
    const otherCompletedPayments = order.payments.filter(
      (p) => p.id !== paymentId && p.status === "completed"
    );
    const totalPaidAfterRefund = otherCompletedPayments.reduce((sum, p) => sum + p.amount, 0);

    if (totalPaidAfterRefund < order.total - 0.01 && order.status === "completed") {
      await prisma.order.update({
        where: { id: order.id },
        data: { status: "served", completedAt: null },
      });

      if (order.tableId) {
        await prisma.table.update({
          where: { id: order.tableId },
          data: { status: "occupied" },
        });
      }
    }

    return updated;
  }

  async getSummary(tenantId: string, dateFrom?: string, dateTo?: string) {
    const where: any = { tenantId, status: "completed" };
    if (dateFrom || dateTo) {
      where.createdAt = {};
      if (dateFrom) where.createdAt.gte = new Date(dateFrom);
      if (dateTo) where.createdAt.lte = new Date(dateTo);
    }

    const [payments, totalRevenue, totalTips, byMethod] = await Promise.all([
      prisma.payment.findMany({ where }),
      prisma.payment.aggregate({ where, _sum: { amount: true } }),
      prisma.payment.aggregate({ where, _sum: { tipAmount: true } }),
      prisma.payment.groupBy({
        by: ["method"],
        where,
        _sum: { amount: true },
        _count: true,
      }),
    ]);

    return {
      totalRevenue: totalRevenue._sum.amount || 0,
      totalTips: totalTips._sum.tipAmount || 0,
      totalTransactions: payments.length,
      byMethod: byMethod.map((m) => ({
        method: m.method,
        total: m._sum.amount || 0,
        count: m._count,
      })),
    };
  }
}

export const paymentService = new PaymentService();
