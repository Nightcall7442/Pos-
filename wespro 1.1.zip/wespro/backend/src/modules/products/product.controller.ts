import { Request, Response } from "express";
import { productService } from "./product.service.js";
import { sendSuccess, sendCreated, sendError, sendPaginated } from "../../utils/response.js";
import type { ProductQueryInput } from "./product.schema.js";

export class ProductController {
  async findAll(req: Request, res: Response) {
    try {
      const query: ProductQueryInput = {
        search: req.query.search as string,
        categoryId: req.query.categoryId as string,
        isActive: req.query.isActive !== undefined ? req.query.isActive === "true" : undefined,
        isIngredient: req.query.isIngredient !== undefined ? req.query.isIngredient === "true" : undefined,
        minPrice: req.query.minPrice ? Number(req.query.minPrice) : undefined,
        maxPrice: req.query.maxPrice ? Number(req.query.maxPrice) : undefined,
        inStock: req.query.inStock !== undefined ? req.query.inStock === "true" : undefined,
        sort: (req.query.sort as any) || "sortOrder",
        order: (req.query.order as any) || "asc",
        page: Number(req.query.page) || 1,
        limit: Number(req.query.limit) || 20,
      };
      const { products, total, page, limit } = await productService.findAll(req.user!.tenantId, query);
      sendPaginated(res, products, total, page, limit);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async findById(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const product = await productService.findById(req.user!.tenantId, id);
      sendSuccess(res, product);
    } catch (error: any) {
      sendError(res, error.message, 404);
    }
  }

  async create(req: Request, res: Response) {
    try {
      const product = await productService.create(req.user!.tenantId, req.body);
      sendCreated(res, product);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async update(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const product = await productService.update(req.user!.tenantId, id, req.body);
      sendSuccess(res, product);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async delete(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      await productService.delete(req.user!.tenantId, id);
      sendSuccess(res, null, "Product deleted");
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async adjustStock(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const { quantity, reason } = req.body;
      const product = await productService.adjustStock(
        req.user!.tenantId,
        id,
        quantity,
        reason,
        req.user!.id
      );
      sendSuccess(res, product);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async getIngredients(req: Request, res: Response) {
    try {
      const ingredients = await productService.getIngredients(req.user!.tenantId);
      sendSuccess(res, ingredients);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async calculateTechCardCost(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const cost = await productService.calculateTechCardCost(req.user!.tenantId, id);
      sendSuccess(res, { cost });
    } catch (error: any) {
      sendError(res, error.message);
    }
  }
}

export const productController = new ProductController();
