import { z } from "zod";

const techCardItemSchema = z.object({
  ingredientId: z.string().uuid(),
  quantity: z.number().positive(),
  unit: z.string().min(1),
  grossWeight: z.number().positive().optional(),
  netWeight: z.number().positive().optional(),
});

export const createProductSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  categoryId: z.string().uuid().optional(),
  sku: z.string().optional(),
  barcode: z.string().optional(),
  price: z.number().min(0),
  costPrice: z.number().min(0).optional(),
  compareAtPrice: z.number().min(0).optional(),
  taxRate: z.number().min(0).max(100).optional(),
  unit: z.string().optional(),
  purchaseUnit: z.string().optional(),
  saleUnit: z.string().optional(),
  conversionFactor: z.number().positive().optional(),
  minStock: z.number().min(0).optional(),
  currentStock: z.number().min(0).optional(),
  trackInventory: z.boolean().optional(),
  isIngredient: z.boolean().optional(),
  techCardId: z.string().uuid().optional().nullable(),
  techCard: z.array(techCardItemSchema).optional(),
  preparationArea: z.string().optional(),
  cookingMethod: z.string().optional(),
  noDiscounts: z.boolean().optional(),
  imageUrl: z.string().optional().transform((v) => v === "" ? undefined : v),
  tags: z.array(z.string()).optional(),
  sortOrder: z.number().int().optional(),
  isActive: z.boolean().optional(),
});

export const updateProductSchema = createProductSchema.partial();

export const productQuerySchema = z.object({
  search: z.string().optional(),
  categoryId: z.string().uuid().optional(),
  isActive: z.coerce.boolean().optional(),
  isIngredient: z.coerce.boolean().optional(),
  minPrice: z.coerce.number().optional(),
  maxPrice: z.coerce.number().optional(),
  inStock: z.coerce.boolean().optional(),
  sort: z.enum(["name", "price", "createdAt", "sortOrder"]).optional(),
  order: z.enum(["asc", "desc"]).optional(),
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
});

export type CreateProductInput = z.infer<typeof createProductSchema>;
export type UpdateProductInput = z.infer<typeof updateProductSchema>;
export type ProductQueryInput = z.infer<typeof productQuerySchema>;
