import prisma from "../../config/database.js";

export class ReportService {
  async getDashboard(tenantId: string) {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const [
      todayOrders,
      todayRevenue,
      weekRevenue,
      monthRevenue,
      activeOrders,
      totalProducts,
      lowStockProducts,
      recentOrders,
    ] = await Promise.all([
      prisma.order.count({
        where: { tenantId, createdAt: { gte: todayStart }, status: { not: "cancelled" } },
      }),
      prisma.payment.aggregate({
        where: { tenantId, status: "completed", createdAt: { gte: todayStart } },
        _sum: { amount: true },
      }),
      prisma.payment.aggregate({
        where: { tenantId, status: "completed", createdAt: { gte: weekStart } },
        _sum: { amount: true },
      }),
      prisma.payment.aggregate({
        where: { tenantId, status: "completed", createdAt: { gte: monthStart } },
        _sum: { amount: true },
      }),
      prisma.order.count({
        where: { tenantId, status: { in: ["pending", "confirmed", "preparing", "ready", "served"] } },
      }),
      prisma.product.count({ where: { tenantId, isActive: true } }),
      prisma.product.count({
        where: { tenantId, trackInventory: true, isActive: true },
      }),
      prisma.order.findMany({
        where: { tenantId },
        include: {
          items: { select: { quantity: true, totalPrice: true } },
          user: { select: { firstName: true } },
        },
        orderBy: { createdAt: "desc" },
        take: 10,
      }),
    ]);

    return {
      todayOrders,
      todayRevenue: todayRevenue._sum.amount || 0,
      weekRevenue: weekRevenue._sum.amount || 0,
      monthRevenue: monthRevenue._sum.amount || 0,
      activeOrders,
      totalProducts,
      lowStockProducts,
      recentOrders,
    };
  }

  async getSalesReport(tenantId: string, dateFrom: string, dateTo: string) {
    const start = new Date(dateFrom);
    const end = new Date(dateTo);

    const [revenue, orders, topProducts, rawSalesByHour] = await Promise.all([
      prisma.payment.aggregate({
        where: {
          tenantId,
          status: "completed",
          createdAt: { gte: start, lte: end },
        },
        _sum: { amount: true, tipAmount: true },
        _count: true,
      }),
      prisma.order.groupBy({
        by: ["type"],
        where: {
          tenantId,
          createdAt: { gte: start, lte: end },
          status: { not: "cancelled" },
        },
        _count: true,
        _sum: { total: true },
      }),
      prisma.orderItem.groupBy({
        by: ["productId"],
        where: {
          order: { tenantId, createdAt: { gte: start, lte: end }, status: { not: "cancelled" } },
        },
        _sum: { quantity: true, totalPrice: true },
        _count: true,
        orderBy: { _sum: { totalPrice: "desc" } },
        take: 10,
      }),
      prisma.order.findMany({
        where: {
          tenantId,
          createdAt: { gte: start, lte: end },
          status: { not: "cancelled" },
        },
        select: { createdAt: true, total: true },
      }),
    ]);

    const hourMap = new Map<string, { order_count: number; revenue: number }>();
    for (const o of rawSalesByHour) {
      const hour = o.createdAt.toISOString().slice(11, 13);
      const existing = hourMap.get(hour) || { order_count: 0, revenue: 0 };
      existing.order_count += 1;
      existing.revenue += o.total;
      hourMap.set(hour, existing);
    }
    const salesByHour = Array.from(hourMap.entries())
      .map(([hour, data]) => ({ hour, ...data }))
      .sort((a, b) => a.hour.localeCompare(b.hour));

    return {
      totalRevenue: revenue._sum.amount || 0,
      totalTips: revenue._sum.tipAmount || 0,
      totalTransactions: revenue._count,
      ordersByType: orders,
      topProducts,
      salesByHour,
    };
  }

  async getEmployeeReport(tenantId: string, dateFrom: string, dateTo: string) {
    const start = new Date(dateFrom);
    const end = new Date(dateTo);

    const employees = await prisma.user.findMany({
      where: { tenantId, isActive: true },
      include: {
        orders: {
          where: { createdAt: { gte: start, lte: end }, status: { not: "cancelled" } },
          select: { total: true, createdAt: true },
        },
      },
    });

    return employees.map((emp) => ({
      id: emp.id,
      name: `${emp.firstName} ${emp.lastName}`,
      role: emp.role,
      ordersCount: emp.orders.length,
      totalSales: emp.orders.reduce((sum, o) => sum + o.total, 0),
    }));
  }
}

export const reportService = new ReportService();
