import prisma from "../../config/database.js";
import type { CreateStockReceiptInput } from "./stock-receipt.schema.js";

function computeSalePrice(costPrice: number, markupPercent: number): number {
  const price = costPrice * (1 + markupPercent / 100);
  return Math.round(price * 100) / 100;
}

export class StockReceiptService {
  async create(tenantId: string, userId: string, data: CreateStockReceiptInput) {
    const tenant = await prisma.tenant.findUnique({ where: { id: tenantId } });
    const defaultMarkup = tenant?.defaultMarkupPercent ?? 0;

    // Resolve each item to a concrete productId, creating categories/products inline as needed
    const newCategoryCache = new Map<string, string>();
    const resolvedItems: { productId: string; quantity: number; costPrice: number }[] = [];

    for (const item of data.items) {
      let productId = item.productId;

      if (!productId && item.newProduct) {
        let categoryId = item.newProduct.categoryId;

        if (!categoryId && item.newProduct.newCategoryName) {
          const name = item.newProduct.newCategoryName.trim();
          const key = name.toLowerCase();
          if (newCategoryCache.has(key)) {
            categoryId = newCategoryCache.get(key);
          } else {
            const existing = await prisma.category.findFirst({ where: { tenantId, name } });
            if (existing) {
              categoryId = existing.id;
            } else {
              const created = await prisma.category.create({
                data: { tenantId, name, markupPercent: defaultMarkup },
              });
              categoryId = created.id;
            }
            newCategoryCache.set(key, categoryId as string);
          }
        }

        const category = categoryId
          ? await prisma.category.findFirst({ where: { id: categoryId, tenantId } })
          : null;
        const markupPercent = category?.markupPercent ?? defaultMarkup;
        const price = computeSalePrice(item.costPrice, markupPercent);

        const product = await prisma.product.create({
          data: {
            tenantId,
            categoryId,
            name: item.newProduct.name.trim(),
            unit: item.newProduct.unit || "piece",
            costPrice: item.costPrice,
            price,
            currentStock: 0,
            trackInventory: true,
          },
        });
        productId = product.id;
      }

      if (!productId) throw new Error("Не указан товар для позиции прихода");
      resolvedItems.push({ productId, quantity: item.quantity, costPrice: item.costPrice });
    }

    const totalAmount = resolvedItems.reduce((sum, item) => sum + item.quantity * item.costPrice, 0);

    const receipt = await prisma.stockReceipt.create({
      data: {
        tenantId,
        userId,
        supplierName: data.supplierName,
        invoiceNumber: data.invoiceNumber,
        totalAmount,
        notes: data.notes,
        items: {
          create: resolvedItems.map((item) => ({
            productId: item.productId,
            quantity: item.quantity,
            costPrice: item.costPrice,
            totalCost: item.quantity * item.costPrice,
          })),
        },
      },
      include: {
        items: {
          include: {
            product: { select: { id: true, name: true, sku: true } },
          },
        },
        user: { select: { id: true, firstName: true, lastName: true } },
      },
    });

    for (const item of resolvedItems) {
      const product = await prisma.product.findFirst({
        where: { id: item.productId, tenantId },
        include: { category: true },
      });
      if (product) {
        const newStock = product.currentStock + item.quantity;
        const markupPercent = product.category?.markupPercent ?? defaultMarkup;
        const newPrice = computeSalePrice(item.costPrice, markupPercent);
        await prisma.product.update({
          where: { id: item.productId },
          data: { currentStock: newStock, costPrice: item.costPrice, price: newPrice },
        });

        await prisma.inventoryMovement.create({
          data: {
            tenantId,
            productId: item.productId,
            type: "in",
            quantity: item.quantity,
            reason: `Приход #${receipt.id.slice(0, 8)}`,
            userId,
          },
        });
      }
    }

    return receipt;
  }

  async findAll(tenantId: string, query: any) {
    const { page = 1, limit = 20, dateFrom, dateTo, supplierName } = query;
    const skip = (page - 1) * limit;

    const where: any = { tenantId };
    if (dateFrom || dateTo) {
      where.createdAt = {};
      if (dateFrom) where.createdAt.gte = new Date(dateFrom);
      if (dateTo) where.createdAt.lte = new Date(dateTo);
    }
    if (supplierName) where.supplierName = { contains: supplierName };

    const [receipts, total] = await Promise.all([
      prisma.stockReceipt.findMany({
        where,
        include: {
          items: {
            include: {
              product: { select: { id: true, name: true, sku: true } },
            },
          },
          user: { select: { id: true, firstName: true, lastName: true } },
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
      }),
      prisma.stockReceipt.count({ where }),
    ]);

    return { receipts, total, page, limit };
  }

  async findById(tenantId: string, id: string) {
    const receipt = await prisma.stockReceipt.findFirst({
      where: { id, tenantId },
      include: {
        items: {
          include: {
            product: { select: { id: true, name: true, sku: true, volume: true } },
          },
        },
        user: { select: { id: true, firstName: true, lastName: true } },
      },
    });
    if (!receipt) throw new Error("Receipt not found");
    return receipt;
  }

  async delete(tenantId: string, id: string) {
    const receipt = await prisma.stockReceipt.findFirst({ where: { id, tenantId } });
    if (!receipt) throw new Error("Receipt not found");

    const items = await prisma.stockReceiptItem.findMany({ where: { receiptId: id } });
    for (const item of items) {
      const product = await prisma.product.findFirst({ where: { id: item.productId, tenantId } });
      if (product) {
        const newStock = Math.max(0, product.currentStock - item.quantity);
        await prisma.product.update({
          where: { id: item.productId },
          data: { currentStock: newStock },
        });
      }
    }

    await prisma.stockReceipt.delete({ where: { id } });
    return { message: "Receipt deleted" };
  }
}

export const stockReceiptService = new StockReceiptService();
