import { Request, Response } from "express";
import { tableService } from "./table.service.js";
import { sendSuccess, sendCreated, sendError } from "../../utils/response.js";

export class TableController {
  async findAll(req: Request, res: Response) {
    try {
      const tables = await tableService.findAll(req.user!.tenantId, req.query.branchId as string);
      sendSuccess(res, tables);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async findById(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const table = await tableService.findById(req.user!.tenantId, id);
      sendSuccess(res, table);
    } catch (error: any) {
      sendError(res, error.message, 404);
    }
  }

  async create(req: Request, res: Response) {
    try {
      const table = await tableService.create(req.user!.tenantId, req.body);
      sendCreated(res, table);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async update(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const table = await tableService.update(req.user!.tenantId, id, req.body);
      sendSuccess(res, table);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async updateStatus(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const table = await tableService.updateStatus(req.user!.tenantId, id, req.body.status);
      sendSuccess(res, table);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async delete(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      await tableService.delete(req.user!.tenantId, id);
      sendSuccess(res, null, "Table deleted");
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async getStats(req: Request, res: Response) {
    try {
      const stats = await tableService.getStats(req.user!.tenantId);
      sendSuccess(res, stats);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }
}

export const tableController = new TableController();
