import { Request, Response } from "express";
import { techCardService } from "./tech-card.service.js";
import { sendSuccess, sendCreated, sendError, sendPaginated } from "../../utils/response.js";
import type { TechCardQueryInput } from "./tech-card.schema.js";

export class TechCardController {
  async findAll(req: Request, res: Response) {
    try {
      const query: TechCardQueryInput = {
        search: req.query.search as string,
        isActive: req.query.isActive !== undefined ? req.query.isActive === "true" : undefined,
        sort: (req.query.sort as any) || "name",
        order: (req.query.order as any) || "asc",
        page: Number(req.query.page) || 1,
        limit: Number(req.query.limit) || 20,
      };
      const { techCards, total, page, limit } = await techCardService.findAll(req.user!.tenantId, query);
      sendPaginated(res, techCards, total, page, limit);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async findById(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const techCard = await techCardService.findById(req.user!.tenantId, id);
      sendSuccess(res, techCard);
    } catch (error: any) {
      sendError(res, error.message, 404);
    }
  }

  async create(req: Request, res: Response) {
    try {
      const techCard = await techCardService.create(req.user!.tenantId, req.body);
      sendCreated(res, techCard);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async update(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const techCard = await techCardService.update(req.user!.tenantId, id, req.body);
      sendSuccess(res, techCard);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async delete(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      await techCardService.delete(req.user!.tenantId, id);
      sendSuccess(res, null, "Tech card deleted");
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async copy(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const techCard = await techCardService.copy(req.user!.tenantId, id);
      sendCreated(res, techCard);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async recalculateCost(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const techCard = await techCardService.recalculateCost(req.user!.tenantId, id);
      sendSuccess(res, techCard);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }
}

export const techCardController = new TechCardController();
