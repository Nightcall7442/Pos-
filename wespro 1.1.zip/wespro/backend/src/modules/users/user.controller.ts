import { Request, Response } from "express";
import { userService } from "./user.service.js";
import { sendSuccess, sendCreated, sendError, sendPaginated } from "../../utils/response.js";

export class UserController {
  async findAll(req: Request, res: Response) {
    try {
      const { users, total, page, limit } = await userService.findAll(req.user!.tenantId, {
        search: req.query.search,
        role: req.query.role,
        isActive: req.query.isActive !== undefined ? req.query.isActive === "true" : undefined,
        page: Number(req.query.page) || 1,
        limit: Number(req.query.limit) || 20,
      });
      sendPaginated(res, users, total, page, limit);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async findById(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const user = await userService.findById(req.user!.tenantId, id);
      sendSuccess(res, user);
    } catch (error: any) {
      sendError(res, error.message, 404);
    }
  }

  async create(req: Request, res: Response) {
    try {
      const user = await userService.create(req.user!.tenantId, req.body);
      sendCreated(res, user);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async update(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const user = await userService.update(req.user!.tenantId, id, req.body);
      sendSuccess(res, user);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async delete(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      await userService.delete(req.user!.tenantId, id);
      sendSuccess(res, null, "User deactivated");
    } catch (error: any) {
      sendError(res, error.message);
    }
  }

  async toggleActive(req: Request, res: Response) {
    try {
      const id = req.params.id as string;
      const user = await userService.toggleActive(req.user!.tenantId, id);
      sendSuccess(res, user);
    } catch (error: any) {
      sendError(res, error.message);
    }
  }
}

export const userController = new UserController();
