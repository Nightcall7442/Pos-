import { z } from "zod";

export const createUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  phone: z.string().optional(),
  pin: z.string().max(10).optional(),
  role: z.enum(["admin", "manager", "cashier", "waiter", "kitchen"]),
  branchId: z.string().uuid().optional(),
});

export const updateUserSchema = createUserSchema.omit({ password: true }).partial();

export const userQuerySchema = z.object({
  search: z.string().optional(),
  role: z.string().optional(),
  isActive: z.coerce.boolean().optional(),
  page: z.coerce.number().int().min(1).optional(),
  limit: z.coerce.number().int().min(1).max(100).optional(),
});

export type CreateUserInput = z.infer<typeof createUserSchema>;
export type UpdateUserInput = z.infer<typeof updateUserSchema>;
