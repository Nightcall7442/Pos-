import bcrypt from "bcryptjs";
import prisma from "../../config/database.js";
import type { CreateUserInput, UpdateUserInput } from "./user.schema.js";

export class UserService {
  async findAll(tenantId: string, query: any) {
    const { search, role, isActive, page = 1, limit = 20 } = query;
    const skip = (page - 1) * limit;

    const where: any = { tenantId };
    if (search) {
      where.OR = [
        { firstName: { contains: search } },
        { lastName: { contains: search } },
        { email: { contains: search } },
      ];
    }
    if (role) where.role = role;
    if (isActive !== undefined) where.isActive = isActive;

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        select: {
          id: true,
          email: true,
          firstName: true,
          lastName: true,
          phone: true,
          role: true,
          avatarUrl: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
      }),
      prisma.user.count({ where }),
    ]);

    return { users, total, page, limit };
  }

  async findById(tenantId: string, id: string) {
    const user = await prisma.user.findFirst({
      where: { id, tenantId },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        role: true,
        avatarUrl: true,
        isActive: true,
        lastLoginAt: true,
        createdAt: true,
      },
    });
    if (!user) throw new Error("User not found");
    return user;
  }

  async create(tenantId: string, data: CreateUserInput) {
    const existing = await prisma.user.findFirst({
      where: { tenantId, email: data.email },
    });
    if (existing) throw new Error("Email already in use");

    const passwordHash = await bcrypt.hash(data.password, 12);
    const { password, ...rest } = data;

    return prisma.user.create({
      data: { ...rest, tenantId, passwordHash },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        createdAt: true,
      },
    });
  }

  async update(tenantId: string, id: string, data: UpdateUserInput) {
    const user = await prisma.user.findFirst({ where: { id, tenantId } });
    if (!user) throw new Error("User not found");

    return prisma.user.update({
      where: { id },
      data,
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        role: true,
        isActive: true,
      },
    });
  }

  async delete(tenantId: string, id: string) {
    const user = await prisma.user.findFirst({ where: { id, tenantId } });
    if (!user) throw new Error("User not found");
    if (user.role === "admin") throw new Error("Cannot delete admin user");

    await prisma.user.update({
      where: { id },
      data: { isActive: false },
    });
    return { message: "User deactivated" };
  }

  async toggleActive(tenantId: string, id: string) {
    const user = await prisma.user.findFirst({ where: { id, tenantId } });
    if (!user) throw new Error("User not found");

    return prisma.user.update({
      where: { id },
      data: { isActive: !user.isActive },
    });
  }
}

export const userService = new UserService();
