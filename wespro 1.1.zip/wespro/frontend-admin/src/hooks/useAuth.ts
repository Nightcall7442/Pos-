import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { authService } from "../services";
import { useAuthStore } from "../store/authStore";

export function useLogin() {
  const login = useAuthStore((s) => s.login);

  return useMutation({
    mutationFn: ({ email, password }: { email: string; password: string }) =>
      authService.login(email, password).then((r) => r.data.data),
    onSuccess: (data) => {
      login(data.user, data.accessToken, data.refreshToken);
      toast.success("Добро пожаловать!");
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.error || "Ошибка входа");
    },
  });
}

export function useLogout() {
  const logout = useAuthStore((s) => s.logout);

  return () => {
    logout();
    window.location.href = "/login";
  };
}
