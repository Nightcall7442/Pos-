import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { X, DollarSign, ArrowRight, Lock, TrendingUp, Banknote, CreditCard, QrCode, AlertTriangle } from "lucide-react";
import api from "../services/api";
import toast from "react-hot-toast";
import type { CashShift } from "../types";

const UZS = (n: number): string => `${Math.round(n).toLocaleString("uz-UZ")} сўм`;

interface CloseShiftScreenProps {
  shiftId: string;
  onShiftClosed: (shift: CashShift) => void;
  onCancel: () => void;
}

export default function CloseShiftScreen({ shiftId, onShiftClosed, onCancel }: CloseShiftScreenProps) {
  const [closingCash, setClosingCash] = useState("");
  const [notes, setNotes] = useState("");

  const { data: shift, isLoading } = useQuery<CashShift>({
    queryKey: ["cash-shift", shiftId],
    queryFn: () => api.get(`/cash-shifts/${shiftId}`).then((r) => r.data.data),
  });

  const closeShift = useMutation({
    mutationFn: async () => {
      const res = await api.post(`/cash-shifts/${shiftId}/close`, {
        closingCash: parseFloat(closingCash) || 0,
        notes: notes || undefined,
      });
      return res.data.data as CashShift;
    },
    onSuccess: (closedShift) => {
      toast.success("Смена закрыта!");
      onShiftClosed(closedShift);
    },
    onError: (error: Error & { response?: { data?: { error?: string } } }) => {
      toast.error(error.response?.data?.error || "Ошибка закрытия смены");
    },
  });

  if (isLoading || !shift) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-dark-950">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-dark-500 border-t-primary-500" />
      </div>
    );
  }

  const expectedCash = shift.openingCash + shift.totalCashSales - shift.totalRefunds;
  const parsedClosing = parseFloat(closingCash) || 0;
  const difference = parsedClosing - expectedCash;
  const quickAmounts = [expectedCash, Math.round(expectedCash / 10000) * 10000, Math.ceil(expectedCash / 50000) * 50000];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm" style={{ animation: "fade-in 0.2s ease" }}>
      <div
        className="relative mx-4 w-full max-w-lg max-h-[90vh] rounded-3xl border border-dark-600 bg-dark-800 shadow-2xl overflow-hidden flex flex-col"
        style={{ animation: "scale-in 0.25s ease" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-dark-700 px-6 py-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-danger-500/15">
              <Lock className="h-5 w-5 text-danger-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Закрытие смены</h2>
              <p className="text-xs text-dark-400">
                Открыта: {new Date(shift.openedAt).toLocaleString("ru-RU")}
              </p>
            </div>
          </div>
          <button onClick={onCancel} className="rounded-xl p-2 text-dark-400 hover:bg-dark-700 hover:text-white transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          {/* Summary cards */}
          <div className="grid grid-cols-2 gap-3">
            <SummaryCard icon={<TrendingUp className="h-4 w-4 text-primary-400" />} label="Общие продажи" value={UZS(shift.totalSales)} />
            <SummaryCard icon={<Banknote className="h-4 w-4 text-success-400" />} label="Наличные" value={UZS(shift.totalCashSales)} />
            <SummaryCard icon={<CreditCard className="h-4 w-4 text-blue-400" />} label="Карта" value={UZS(shift.totalCardSales)} />
            <SummaryCard icon={<QrCode className="h-4 w-4 text-purple-400" />} label="QR" value={UZS(shift.totalQrSales)} />
          </div>

          {/* Opening / Expected */}
          <div className="rounded-xl border border-dark-600 bg-dark-700/50 p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-dark-400">Начальная наличность</span>
              <span className="font-medium text-white">{UZS(shift.openingCash)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-dark-400">Ожидаемая наличность</span>
              <span className="font-bold text-primary-400">{UZS(expectedCash)}</span>
            </div>
          </div>

          {/* Closing cash input */}
          <div>
            <label className="mb-2 block text-sm font-medium text-dark-300">
              Фактическая наличность в кассе
            </label>
            <div className="relative">
              <DollarSign className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-dark-400" />
              <input
                type="number"
                step="10000"
                value={closingCash}
                onChange={(e) => setClosingCash(e.target.value)}
                placeholder="0"
                className="w-full rounded-xl border-2 border-dark-600 bg-dark-700 py-4 pl-12 pr-4 text-center text-3xl font-bold text-white placeholder:text-dark-500 focus:border-primary-500 focus:outline-none transition-colors"
                autoFocus
              />
            </div>
          </div>

          {/* Quick amounts */}
          <div className="grid grid-cols-3 gap-2">
            {quickAmounts.map((amount) => (
              <button
                key={amount}
                onClick={() => setClosingCash(String(Math.round(amount)))}
                className="rounded-xl border border-dark-600 bg-dark-700 py-2 text-xs font-semibold text-dark-300 transition-all hover:border-primary-500/50 hover:text-white active:scale-95"
              >
                {UZS(amount)}
              </button>
            ))}
          </div>

          {/* Difference indicator */}
          {closingCash && (
            <div
              className={`rounded-xl border p-4 text-center ${
                difference === 0
                  ? "border-success-500/30 bg-success-500/10"
                  : difference > 0
                  ? "border-primary-500/30 bg-primary-500/10"
                  : "border-danger-500/30 bg-danger-500/10"
              }`}
              style={{ animation: "pop-in 0.2s ease" }}
            >
              <div className="flex items-center justify-center gap-2 mb-1">
                {difference !== 0 && <AlertTriangle className="h-4 w-4" />}
                <p className="text-xs font-medium text-dark-400">
                  {difference === 0 ? "Без расхождений" : difference > 0 ? "Излишек" : "Недостача"}
                </p>
              </div>
              <p
                className={`text-2xl font-bold ${
                  difference === 0 ? "text-success-500" : difference > 0 ? "text-primary-400" : "text-danger-400"
                }`}
              >
                {difference === 0 ? "0" : (difference > 0 ? "+" : "") + UZS(Math.abs(difference))}
              </p>
            </div>
          )}

          {/* Notes */}
          <div>
            <label className="mb-2 block text-sm font-medium text-dark-300">Примечания</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Необязательно..."
              rows={2}
              className="w-full rounded-xl border-2 border-dark-600 bg-dark-700 py-3 px-4 text-sm text-white placeholder:text-dark-500 focus:border-primary-500 focus:outline-none transition-colors resize-none"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-dark-700 px-6 py-4 shrink-0">
          <div className="flex gap-3">
            <button
              onClick={onCancel}
              className="flex-1 rounded-xl border border-dark-600 bg-dark-700 py-3 text-sm font-medium text-dark-300 hover:text-white transition-colors"
            >
              Отмена
            </button>
            <button
              onClick={() => closeShift.mutate()}
              disabled={closeShift.isPending || !closingCash}
              className="flex-[2] flex items-center justify-center gap-2 rounded-xl bg-danger-600 py-3 text-sm font-bold text-white shadow-lg shadow-danger-600/30 transition-all hover:bg-danger-500 active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {closeShift.isPending ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  Закрытие...
                </>
              ) : (
                <>
                  Закрыть смену
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function SummaryCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-xl border border-dark-600 bg-dark-700/50 p-3">
      <div className="flex items-center gap-2 mb-1">
        {icon}
        <span className="text-[11px] text-dark-400">{label}</span>
      </div>
      <p className="text-sm font-bold text-white">{value}</p>
    </div>
  );
}
