import { useState, useMemo } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { X, Plus, Trash2, PackagePlus, Loader2 } from "lucide-react";
import api from "../services/api";
import toast from "react-hot-toast";
import type { Category, Product } from "../types";

interface StockReceiptScreenProps {
  onClose: () => void;
}

interface StagedItem {
  key: string;
  quantity: number;
  costPrice: number;
  salePrice: number;
  label: string;
  categoryLabel: string;
  payload:
    | { productId: string }
    | { newProduct: { name: string; categoryId?: string; newCategoryName?: string; unit: string } };
}

const UZS = (n: number): string => `${Math.round(n).toLocaleString("uz-UZ")} сўм`;

function computeSalePrice(costPrice: number, markupPercent: number): number {
  const price = costPrice * (1 + markupPercent / 100);
  return Math.round(price * 100) / 100;
}

export default function StockReceiptScreen({ onClose }: StockReceiptScreenProps) {
  const qc = useQueryClient();

  const [supplierName, setSupplierName] = useState("");
  const [items, setItems] = useState<StagedItem[]>([]);

  const [categoryMode, setCategoryMode] = useState<"existing" | "new">("existing");
  const [categoryId, setCategoryId] = useState("");
  const [newCategoryName, setNewCategoryName] = useState("");

  const [productMode, setProductMode] = useState<"existing" | "new">("existing");
  const [productId, setProductId] = useState("");
  const [newProductName, setNewProductName] = useState("");
  const [unit, setUnit] = useState("шт");

  const [quantity, setQuantity] = useState("1");
  const [costPrice, setCostPrice] = useState("");

  const { data: settings } = useQuery({
    queryKey: ["settings-markup"],
    queryFn: () => api.get("/settings").then((r) => r.data.data),
  });
  const defaultMarkup = Number(settings?.defaultMarkupPercent) || 0;

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["categories"],
    queryFn: () => api.get("/categories").then((r) => r.data.data),
  });

  const { data: categoryProducts } = useQuery<Product[]>({
    queryKey: ["products-for-receipt", categoryId],
    queryFn: () =>
      api
        .get("/products", { params: { categoryId, limit: 200, isActive: undefined } })
        .then((r) => r.data.data as Product[]),
    enabled: categoryMode === "existing" && !!categoryId,
  });

  const selectedCategory = categories?.find((c) => c.id === categoryId);
  const effectiveMarkup = categoryMode === "existing" && selectedCategory ? Number(selectedCategory.markupPercent) || 0 : defaultMarkup;

  const previewPrice = useMemo(() => {
    const cost = parseFloat(costPrice);
    if (!cost || cost <= 0) return 0;
    return computeSalePrice(cost, effectiveMarkup);
  }, [costPrice, effectiveMarkup]);

  const canAdd =
    (categoryMode === "existing" ? !!categoryId : newCategoryName.trim().length > 0) &&
    (productMode === "existing" ? !!productId : newProductName.trim().length > 0) &&
    parseFloat(quantity) > 0 &&
    parseFloat(costPrice) >= 0 &&
    costPrice !== "";

  const resetProductFields = (): void => {
    setProductId("");
    setNewProductName("");
    setQuantity("1");
    setCostPrice("");
  };

  const handleCategoryModeChange = (mode: "existing" | "new"): void => {
    setCategoryMode(mode);
    setCategoryId("");
    setNewCategoryName("");
    setProductMode(mode === "new" ? "new" : "existing");
    resetProductFields();
  };

  const handleAddItem = (): void => {
    if (!canAdd) return;
    const qty = parseFloat(quantity);
    const cost = parseFloat(costPrice);
    const sale = computeSalePrice(cost, effectiveMarkup);

    let payload: StagedItem["payload"];
    let label: string;
    let categoryLabel: string;

    if (productMode === "existing") {
      const product = categoryProducts?.find((p) => p.id === productId);
      payload = { productId };
      label = product?.name || "Товар";
      categoryLabel = selectedCategory?.name || "";
    } else {
      payload = {
        newProduct: {
          name: newProductName.trim(),
          unit,
          ...(categoryMode === "existing" ? { categoryId } : { newCategoryName: newCategoryName.trim() }),
        },
      };
      label = `${newProductName.trim()} (новый)`;
      categoryLabel = categoryMode === "existing" ? selectedCategory?.name || "" : `${newCategoryName.trim()} (новая)`;
    }

    setItems((prev) => [
      ...prev,
      { key: `${Date.now()}-${Math.random()}`, quantity: qty, costPrice: cost, salePrice: sale, label, categoryLabel, payload },
    ]);
    resetProductFields();
  };

  const handleRemoveItem = (key: string): void => {
    setItems((prev) => prev.filter((i) => i.key !== key));
  };

  const total = items.reduce((sum, i) => sum + i.quantity * i.costPrice, 0);

  const createMutation = useMutation({
    mutationFn: () =>
      api.post("/stock-receipts", {
        supplierName: supplierName || undefined,
        items: items.map((i) => ({ ...i.payload, quantity: i.quantity, costPrice: i.costPrice })),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["categories"] });
      qc.invalidateQueries({ queryKey: ["products-all"] });
      qc.invalidateQueries({ queryKey: ["products-for-receipt"] });
      toast.success("Приход оформлен");
      onClose();
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.error || "Не удалось оформить приход");
    },
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" style={{ animation: "fade-in 0.2s ease" }}>
      <div
        className="flex max-h-[90vh] w-full max-w-3xl flex-col rounded-3xl border border-dark-600 bg-dark-800 shadow-2xl"
        style={{ animation: "scale-in 0.2s ease" }}
      >
        <div className="flex items-center justify-between border-b border-dark-700 px-6 py-4 shrink-0">
          <div className="flex items-center gap-2">
            <PackagePlus className="h-5 w-5 text-primary-400" />
            <h3 className="text-lg font-bold text-white">Приход товара</h3>
          </div>
          <button onClick={onClose} className="rounded-xl p-2 text-dark-400 hover:bg-dark-700 hover:text-white transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-5">
          <div>
            <label className="mb-1 block text-xs font-medium text-dark-400">Поставщик (необязательно)</label>
            <input
              value={supplierName}
              onChange={(e) => setSupplierName(e.target.value)}
              placeholder="Название поставщика"
              className="w-full rounded-xl border-2 border-dark-600 bg-dark-700 px-3 py-2 text-sm text-white placeholder:text-dark-500 focus:border-primary-500 focus:outline-none"
            />
          </div>

          <div className="rounded-2xl border border-dark-700 bg-dark-900/50 p-4 space-y-4">
            {/* Category */}
            <div>
              <label className="mb-1.5 block text-xs font-medium text-dark-400">Категория</label>
              <div className="mb-2 flex gap-1.5">
                <button
                  onClick={() => handleCategoryModeChange("existing")}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                    categoryMode === "existing" ? "bg-primary-600 text-white" : "bg-dark-700 text-dark-400 hover:text-white"
                  }`}
                >
                  Существующая
                </button>
                <button
                  onClick={() => handleCategoryModeChange("new")}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                    categoryMode === "new" ? "bg-primary-600 text-white" : "bg-dark-700 text-dark-400 hover:text-white"
                  }`}
                >
                  + Новая категория
                </button>
              </div>
              {categoryMode === "existing" ? (
                <select
                  value={categoryId}
                  onChange={(e) => {
                    setCategoryId(e.target.value);
                    setProductMode("existing");
                    resetProductFields();
                  }}
                  className="w-full rounded-xl border-2 border-dark-600 bg-dark-700 px-3 py-2 text-sm text-white focus:border-primary-500 focus:outline-none"
                >
                  <option value="">Выберите категорию</option>
                  {categories?.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} (наценка {Number(c.markupPercent) || 0}%)
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  placeholder="Название новой категории"
                  className="w-full rounded-xl border-2 border-dark-600 bg-dark-700 px-3 py-2 text-sm text-white placeholder:text-dark-500 focus:border-primary-500 focus:outline-none"
                />
              )}
              {categoryMode === "new" && (
                <p className="mt-1.5 text-[11px] text-dark-500">
                  Наценка по умолчанию {defaultMarkup}% (задаётся администратором в настройках). Изменить наценку для этой категории можно в админ-панели.
                </p>
              )}
            </div>

            {/* Product */}
            <div>
              <label className="mb-1.5 block text-xs font-medium text-dark-400">Товар</label>
              {categoryMode === "existing" && categoryId && (
                <div className="mb-2 flex gap-1.5">
                  <button
                    onClick={() => {
                      setProductMode("existing");
                      resetProductFields();
                    }}
                    className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                      productMode === "existing" ? "bg-primary-600 text-white" : "bg-dark-700 text-dark-400 hover:text-white"
                    }`}
                  >
                    Существующий
                  </button>
                  <button
                    onClick={() => {
                      setProductMode("new");
                      resetProductFields();
                    }}
                    className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                      productMode === "new" ? "bg-primary-600 text-white" : "bg-dark-700 text-dark-400 hover:text-white"
                    }`}
                  >
                    + Новый товар
                  </button>
                </div>
              )}

              {productMode === "existing" ? (
                <select
                  value={productId}
                  onChange={(e) => setProductId(e.target.value)}
                  disabled={!categoryId}
                  className="w-full rounded-xl border-2 border-dark-600 bg-dark-700 px-3 py-2 text-sm text-white focus:border-primary-500 focus:outline-none disabled:opacity-40"
                >
                  <option value="">{categoryId ? "Выберите товар" : "Сначала выберите категорию"}</option>
                  {categoryProducts?.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (остаток {p.currentStock})
                    </option>
                  ))}
                </select>
              ) : (
                <div className="flex gap-2">
                  <input
                    value={newProductName}
                    onChange={(e) => setNewProductName(e.target.value)}
                    placeholder="Название товара"
                    className="flex-1 rounded-xl border-2 border-dark-600 bg-dark-700 px-3 py-2 text-sm text-white placeholder:text-dark-500 focus:border-primary-500 focus:outline-none"
                  />
                  <input
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    placeholder="ед."
                    className="w-20 rounded-xl border-2 border-dark-600 bg-dark-700 px-3 py-2 text-sm text-white placeholder:text-dark-500 focus:border-primary-500 focus:outline-none"
                  />
                </div>
              )}
            </div>

            {/* Quantity + cost price */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-dark-400">Количество</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="w-full rounded-xl border-2 border-dark-600 bg-dark-700 px-3 py-2 text-sm text-white focus:border-primary-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-dark-400">Цена прихода (за ед.)</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={costPrice}
                  onChange={(e) => setCostPrice(e.target.value)}
                  className="w-full rounded-xl border-2 border-dark-600 bg-dark-700 px-3 py-2 text-sm text-white focus:border-primary-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-between rounded-xl bg-dark-800 px-4 py-3">
              <span className="text-xs text-dark-400">
                Цена продажи (наценка {effectiveMarkup}%)
              </span>
              <span className="text-lg font-bold text-primary-400">{previewPrice > 0 ? UZS(previewPrice) : "—"}</span>
            </div>

            <button
              onClick={handleAddItem}
              disabled={!canAdd}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-dark-700 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-dark-600 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Plus className="h-4 w-4" />
              Добавить в приход
            </button>
          </div>

          {/* Staged items list */}
          {items.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-dark-500">Позиции прихода ({items.length})</h4>
              {items.map((item) => (
                <div key={item.key} className="flex items-center gap-3 rounded-xl border border-dark-700 bg-dark-900/50 px-4 py-2.5">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-white">{item.label}</p>
                    <p className="text-[11px] text-dark-500">
                      {item.categoryLabel} · {item.quantity} × {UZS(item.costPrice)} → продажа {UZS(item.salePrice)}
                    </p>
                  </div>
                  <span className="text-sm font-bold text-white">{UZS(item.quantity * item.costPrice)}</span>
                  <button onClick={() => handleRemoveItem(item.key)} className="text-dark-500 hover:text-danger-500 transition-colors">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between gap-4 border-t border-dark-700 px-6 py-4 shrink-0 bg-dark-800/80">
          <div>
            <p className="text-xs text-dark-400">Итого по приходу</p>
            <p className="text-xl font-bold text-white">{UZS(total)}</p>
          </div>
          <button
            onClick={() => createMutation.mutate()}
            disabled={items.length === 0 || createMutation.isPending}
            className="flex items-center gap-2 rounded-xl bg-primary-600 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-primary-600/25 transition-all hover:bg-primary-500 active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {createMutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
            Оформить приход
          </button>
        </div>
      </div>
    </div>
  );
}
