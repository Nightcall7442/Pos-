import { io, Socket } from "socket.io-client";

let socket: Socket | null = null;

export function getSocket(): Socket {
  if (!socket) {
    socket = io(window.location.origin, {
      path: "/socket.io",
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      auth: {
        token: localStorage.getItem("pos-token"),
      },
    });

    socket.on("connect_error", () => {
      // silently retry
    });
  }
  return socket;
}

export function disconnectSocket(): void {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
}

export function emitNewOrder(order: { id: string; orderNumber: string; items: unknown[]; type: string }): void {
  const s = getSocket();
  s.emit("order:new", order);
}
